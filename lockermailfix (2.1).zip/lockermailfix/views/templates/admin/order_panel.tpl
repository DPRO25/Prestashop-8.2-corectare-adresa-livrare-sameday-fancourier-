{*
 * LockermailFix — panou „Livrare” în pagina comenzii (BO)
 *}
{assign var=lmf_type value=''}
{if $lmf_live}{assign var=lmf_type value=$lmf_live.delivery_type}{elseif $lmf_record}{assign var=lmf_type value=$lmf_record.delivery_type}{/if}

<div class="card mt-2 mb-2" style="border-left:5px solid {if $lmf_type=='easybox' || $lmf_type=='pudo'}#e30613{elseif $lmf_type=='fanbox'}#0055a5{else}#6c868e{/if};">
  <div class="card-body py-2">
    <div style="display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start;justify-content:space-between;">
      <div style="min-width:260px;flex:1;">
        <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#6c868e;">Tip livrare</div>
        <div style="font-size:18px;font-weight:700;">
          {if $lmf_type=='easybox'}Sameday easybox
          {elseif $lmf_type=='pudo'}Sameday PUDO (punct de ridicare)
          {elseif $lmf_type=='fanbox'}FAN Courier FANbox
          {else}Livrare la adresă{/if}
        </div>
        <div style="color:#6c868e;">Curier: {$lmf_carrier|escape:'html':'UTF-8'}</div>
      </div>

      {if $lmf_live}
      <div style="min-width:260px;flex:1;">
        <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#6c868e;">Locker / punct ales de client</div>
        <div style="font-weight:700;">{$lmf_live.locker_name|escape:'html':'UTF-8'}</div>
        {if $lmf_live.locker_address}<div>{$lmf_live.locker_address|escape:'html':'UTF-8'}</div>{/if}
        {if $lmf_live.locker_city || $lmf_live.locker_county}
          <div>{$lmf_live.locker_city|escape:'html':'UTF-8'}{if $lmf_live.locker_county}, {$lmf_live.locker_county|escape:'html':'UTF-8'}{/if} {$lmf_live.locker_postcode|escape:'html':'UTF-8'}</div>
        {/if}
        {if $lmf_live.locker_id}<div style="color:#6c868e;">ID: {$lmf_live.locker_id|escape:'html':'UTF-8'}</div>{/if}
      </div>
      {/if}

      <div style="min-width:260px;flex:1;">
        <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#6c868e;">Adresa de livrare a comenzii acum</div>
        <div>{$lmf_current_address nofilter}</div>
      </div>
    </div>

    {if $lmf_record && $lmf_record.error}
      <div class="alert alert-warning mt-2 mb-0">Adresa locker nu a putut fi creată automat: {$lmf_record.error|escape:'html':'UTF-8'}</div>
    {/if}

    {if $lmf_needs_fix}
      <div class="alert alert-info mt-2 mb-0">
        Comanda are locker ales, dar adresa de livrare nu a fost încă înlocuită.
        <a class="btn btn-primary btn-sm ml-2" href="{$lmf_config_url|escape:'html':'UTF-8'}&amp;lmf_fix_order={$lmf_order_id|intval}">Setează adresa lockerului pe comandă</a>
      </div>
    {elseif $lmf_record && $lmf_record.id_address_new > 0}
      <div class="mt-2" style="color:#6c868e;font-size:12px;">
        Adresa de livrare a fost înlocuită automat cu lockerul (adresa inițială a clientului #{$lmf_record.id_address_original|intval} a rămas neatinsă).
        <a href="{$lmf_config_url|escape:'html':'UTF-8'}&amp;lmf_revert_order={$lmf_order_id|intval}">Revino la adresa inițială</a>
      </div>
    {elseif $lmf_record && $lmf_record.reverted}
      <div class="mt-2" style="color:#6c868e;font-size:12px;">
        Comanda a fost readusă manual pe adresa inițială.
        {if $lmf_live}<a href="{$lmf_config_url|escape:'html':'UTF-8'}&amp;lmf_fix_order={$lmf_order_id|intval}">Aplică din nou lockerul</a>{/if}
      </div>
    {/if}
  </div>
</div>
