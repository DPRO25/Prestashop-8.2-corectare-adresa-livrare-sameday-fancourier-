{*
 * LockermailFix — configurare și diagnostic
 *}
{foreach $lmf_messages as $m}
  <div class="alert alert-{$m[0]|escape:'html':'UTF-8'}">{$m[1]|escape:'html':'UTF-8'}</div>
{/foreach}

<div class="panel">
  <div class="panel-heading"><i class="icon-cogs"></i> Setări</div>
  <form method="post" action="{$lmf_action|escape:'html':'UTF-8'}" class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-lg-4">Email de confirmare modern</label>
      <div class="col-lg-8">
        <select name="LMF_MAIL_ENABLED" class="fixed-width-xl">
          <option value="1" {if $lmf_mail_enabled}selected{/if}>Da — folosește emailul nou din modul</option>
          <option value="0" {if !$lmf_mail_enabled}selected{/if}>Nu — trimite emailul standard PrestaShop</option>
        </select>
        <p class="help-block">Șablonul nou este în <code>modules/lockermailfix/mails/ro/order_conf.html</code>. Șablonul standard din <code>/mails/ro/</code> rămâne neatins.</p>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-lg-4">Înlocuiește adresa de livrare a comenzii cu lockerul</label>
      <div class="col-lg-8">
        <select name="LMF_REPLACE_ADDRESS" class="fixed-width-xl">
          <option value="1" {if $lmf_replace}selected{/if}>Da (recomandat) — apare în email, BO, factură, AWB</option>
          <option value="0" {if !$lmf_replace}selected{/if}>Nu — doar afișează tipul livrării în BO</option>
        </select>
        <p class="help-block">Adresele din agenda clientului nu sunt modificate niciodată. Pentru comandă se creează o adresă separată, ascunsă din contul clientului.</p>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-lg-4">Curieri FANbox (opțional)</label>
      <div class="col-lg-8">
        <select name="LMF_FAN_CARRIERS[]" multiple size="6" style="min-width:320px;">
          {foreach $lmf_carriers as $c}
            <option value="{$c.id_carrier|intval}" {if in_array($c.id_carrier, $lmf_fan_carriers)}selected{/if}>#{$c.id_carrier|intval} {$c.name|escape:'html':'UTF-8'}</option>
          {/foreach}
        </select>
        <p class="help-block">Dacă selectezi curieri aici, datele FANbox sunt aplicate doar comenzilor cu acești curieri. Gol = orice comandă care are FANbox salvat.</p>
      </div>
    </div>
    <div class="panel-footer">
      <button type="submit" name="submitLmfSettings" class="btn btn-default pull-right"><i class="process-icon-save"></i> Salvează</button>
    </div>
  </form>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-envelope"></i> Testează emailul de confirmare</div>
  <form method="post" action="{$lmf_action|escape:'html':'UTF-8'}" class="form-inline">
    <p>Alege o comandă existentă: o poți previzualiza în browser sau poți primi emailul exact cum îl primește clientul. Clientul comenzii NU primește nimic.</p>
    <div class="form-group" style="margin-right:12px;">
      <label>Comanda #</label>
      <input type="number" name="lmf_test_order" value="{$lmf_last_order|intval}" class="form-control" style="width:110px;">
    </div>
    <div class="form-group" style="margin-right:12px;">
      <label>Trimite la</label>
      <input type="email" name="lmf_test_email" value="{$lmf_employee_email|escape:'html':'UTF-8'}" class="form-control" style="width:260px;">
    </div>
    <button type="submit" name="submitLmfTestMail" class="btn btn-primary">Trimite email de test</button>
    <a class="btn btn-default" target="_blank" href="{$lmf_action|escape:'html':'UTF-8'}&amp;lmf_preview_mail={$lmf_last_order|intval}" onclick="this.href=this.href.replace(/lmf_preview_mail=\d+/, 'lmf_preview_mail=' + document.querySelector('input[name=lmf_test_order]').value);">Previzualizează în browser</a>
  </form>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-wrench"></i> Repară comenzile existente</div>
  <form method="post" action="{$lmf_action|escape:'html':'UTF-8'}" class="form-inline">
    <p>Verifică comenzile din ultimele <input type="number" name="lmf_days" value="30" min="1" max="365" class="form-control" style="width:90px;display:inline-block;"> zile și setează adresa lockerului acolo unde clientul a ales easybox / FANbox. Comenzile deja corectate sunt sărite.</p>
    <button type="submit" name="submitLmfBulk" class="btn btn-primary">Repară comenzile</button>
  </form>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-search"></i> Diagnostic — ultimele 20 de comenzi</div>
  <p>Coloana <b>Detectat acum</b> arată ce găsește modulul pentru fiecare comandă. Dacă o comandă cu easybox / FANbox apare aici ca „—”, trimite o captură a acestei pagini.</p>
  <div class="table-responsive">
  <table class="table">
    <thead><tr>
      <th>#</th><th>Data</th><th>Curier (id)</th><th>Cod Sameday</th><th>Detectat acum</th><th>Sursa</th><th>Adresa livrare comandă</th><th>Stare modul</th><th></th>
    </tr></thead>
    <tbody>
    {foreach $lmf_diag.orders as $o}
      <tr>
        <td>{$o.id_order|intval}<br><small>{$o.reference|escape:'html':'UTF-8'}</small></td>
        <td><small>{$o.date_add|escape:'html':'UTF-8'}</small></td>
        <td>{$o.carrier|escape:'html':'UTF-8'} ({$o.id_carrier|intval})</td>
        <td>{if $o.sameday_code}{$o.sameday_code|escape:'html':'UTF-8'}{else}—{/if}</td>
        <td>{if $o.detected}<b>{$o.detected.delivery_label|escape:'html':'UTF-8'}</b>{if $o.detected.locker_address}<br><small>{$o.detected.locker_address|escape:'html':'UTF-8'}</small>{/if}{else}—{/if}</td>
        <td><small>{if $o.detected}{$o.detected.source|escape:'html':'UTF-8'}{/if}</small></td>
        <td><small>#{$o.id_address_delivery|intval} {$o.delivery_now|escape:'html':'UTF-8'}</small></td>
        <td><small>
          {if !$o.record}neprocesată
          {elseif $o.record.reverted}readusă manual
          {elseif $o.record.id_address_new > 0}<span style="color:#2e7d32;">locker aplicat</span>
          {elseif $o.record.error}<span style="color:#c62828;">eroare: {$o.record.error|escape:'html':'UTF-8'}</span>
          {else}{$o.record.delivery_label|escape:'html':'UTF-8'}{/if}
        </small></td>
        <td>
          {if $o.detected && (!$o.record || !$o.record.id_address_new)}
            <a class="btn btn-default btn-xs" href="{$lmf_action|escape:'html':'UTF-8'}&amp;lmf_fix_order={$o.id_order|intval}">Aplică</a>
          {elseif $o.record && $o.record.id_address_new > 0}
            <a class="btn btn-default btn-xs" href="{$lmf_action|escape:'html':'UTF-8'}&amp;lmf_revert_order={$o.id_order|intval}">Revino</a>
          {/if}
        </td>
      </tr>
    {/foreach}
    </tbody>
  </table>
  </div>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-truck"></i> Curieri Sameday și serviciile lor</div>
  <p>Lockerul Sameday este aplicat doar comenzilor cu servicii <b>LN / XL</b> (easybox) sau <b>PP / XP</b> (PUDO).</p>
  <table class="table">
    <thead><tr><th>id_carrier</th><th>Curier PrestaShop</th><th>Serviciu Sameday</th><th>Cod</th><th>Live</th></tr></thead>
    <tbody>
    {foreach $lmf_diag.sameday_services as $s}
      <tr><td>{$s.id_carrier|intval}</td><td>{$s.carrier_name|escape:'html':'UTF-8'}{if $s.deleted} <small>(șters)</small>{/if}</td><td>{$s.name|escape:'html':'UTF-8'}</td><td><b>{$s.code|escape:'html':'UTF-8'}</b></td><td>{$s.live_mode|intval}</td></tr>
    {foreachelse}
      <tr><td colspan="5">Tabela ps_sameday_services nu există sau nu are curieri asociați.</td></tr>
    {/foreach}
    </tbody>
  </table>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-list"></i> Ordinea modulelor pe actionValidateOrder</div>
  <p>LockermailFix ar trebui să fie ultimul, ca modulele de curierat să-și salveze lockerul înaintea lui.</p>
  <table class="table">
    <thead><tr><th>Shop</th><th>Poziție</th><th>Modul</th></tr></thead>
    <tbody>
    {foreach $lmf_diag.hook_modules as $h}
      <tr {if $h.name=='lockermailfix'}style="font-weight:700;"{/if}><td>{$h.id_shop|intval}</td><td>{$h.position|intval}</td><td>{$h.name|escape:'html':'UTF-8'}</td></tr>
    {/foreach}
    </tbody>
  </table>
  <form method="post" action="{$lmf_action|escape:'html':'UTF-8'}">
    <button type="submit" name="submitLmfHookLast" class="btn btn-default">Mută LockermailFix ultimul</button>
  </form>
</div>

<div class="panel">
  <div class="panel-heading"><i class="icon-table"></i> Tabele curierat găsite în baza de date</div>
  <p>Coloana <code>sameday_locker</code> în ps_cart: <b>{if $lmf_diag.cart_has_sameday_locker}există{else}NU există{/if}</b></p>
  <table class="table">
    <thead><tr><th>Tabelă</th><th>Rânduri</th><th>Coloane</th></tr></thead>
    <tbody>
    {foreach $lmf_diag.tables as $t}
      <tr><td><code>{$t.name|escape:'html':'UTF-8'}</code></td><td>{$t.rows|intval}</td><td><small>{$t.columns|escape:'html':'UTF-8'}</small></td></tr>
    {/foreach}
    </tbody>
  </table>
</div>

{if $lmf_diag.contaminated}
<div class="panel">
  <div class="panel-heading"><i class="icon-warning"></i> Adrese din contul clienților suprascrise de versiunea veche a modulului</div>
  <p>Versiunile 1.0.x scriau lockerul direct peste adresa salvată a clientului. Aceste adrese apar încă în contul clientului ca adrese normale. Verifică-le / corectează-le manual din <b>Clienți › Adrese</b> (adresa reală de acasă a clientului s-a pierdut la suprascriere).</p>
  <table class="table">
    <thead><tr><th>id_address</th><th>id_customer</th><th>Alias</th><th>Adresă</th><th>Oraș</th><th>Comenzi</th></tr></thead>
    <tbody>
    {foreach $lmf_diag.contaminated as $a}
      <tr><td>{$a.id_address|intval}</td><td>{$a.id_customer|intval}</td><td>{$a.alias|escape:'html':'UTF-8'}</td><td>{$a.address1|escape:'html':'UTF-8'} {$a.address2|escape:'html':'UTF-8'}</td><td>{$a.city|escape:'html':'UTF-8'}</td><td>{$a.orders_count|intval}</td></tr>
    {/foreach}
    </tbody>
  </table>
</div>
{/if}
