<?php
/**
 * Upgrade 1.0.x → 2.0.0: tabelă proprie, hook-uri noi, poziție ultimă pe actionValidateOrder.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_0_0($module)
{
    $ok = $module->installDb();
    foreach ($module->getHookList() as $hook) {
        if (!$module->isRegisteredInHook($hook)) {
            $ok = $module->registerHook($hook) && $ok;
        }
    }
    $module->moveHookToLast('actionValidateOrder');
    if (Configuration::get('LMF_REPLACE_ADDRESS') === false) {
        Configuration::updateValue('LMF_REPLACE_ADDRESS', 1);
    }
    if (Configuration::get('LMF_FAN_CARRIERS') === false) {
        Configuration::updateValue('LMF_FAN_CARRIERS', '');
    }

    return (bool) $ok;
}
