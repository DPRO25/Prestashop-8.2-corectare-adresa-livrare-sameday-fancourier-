<?php
/**
 * Upgrade 2.0.x → 2.1.0: email de confirmare modern.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_1_0($module)
{
    $ok = true;
    foreach (['actionEmailSendBefore', 'actionEmailAddAfterContent'] as $hook) {
        if (!$module->isRegisteredInHook($hook)) {
            $ok = $module->registerHook($hook) && $ok;
        }
    }
    if (Configuration::get('LMF_MAIL_ENABLED') === false) {
        Configuration::updateValue('LMF_MAIL_ENABLED', 1);
    }

    return (bool) $ok;
}
