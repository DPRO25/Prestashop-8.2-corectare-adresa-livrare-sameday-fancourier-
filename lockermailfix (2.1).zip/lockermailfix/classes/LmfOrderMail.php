<?php
/**
 * LockermailFix — generează conținutul dinamic pentru emailul de confirmare a comenzii (order_conf).
 *
 * Toate textele vizibile pentru client sunt în LmfOrderMail::$texts — le poți edita acolo.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class LmfOrderMail
{
    /** Culori — simple, fără fonturi speciale */
    const C_TEXT = '#1f2937';
    const C_MUTED = '#6b7280';
    const C_BORDER = '#e5e7eb';
    const C_BG_SOFT = '#f9fafb';
    const C_ACCENT = '#c8102e';
    const C_OK = '#15803d';
    const C_OK_BG = '#ecfdf3';
    const C_WARN = '#b45309';
    const C_WARN_BG = '#fffbeb';
    const FONT = 'Arial, Helvetica, sans-serif';

    const PAY_PAID = 'paid';
    const PAY_COD = 'cod';
    const PAY_WIRE = 'wire';
    const PAY_PENDING = 'pending';

    /** Texte editabile */
    public static $texts = [
        'delivery_title' => [
            'easybox' => 'Livrare în easybox Sameday',
            'pudo' => 'Livrare la punct Sameday (PUDO)',
            'fanbox' => 'Livrare în FANbox',
            'address' => 'Livrare prin curier la adresă',
        ],
        'delivery_note' => [
            'easybox' => 'Când coletul ajunge în easybox, Sameday îți trimite prin SMS și email codul de deschidere. Îl ridici cu acel cod sau din aplicația Sameday.',
            'pudo' => 'Sameday te anunță prin SMS și email când coletul poate fi ridicat de la punctul ales.',
            'fanbox' => 'Când coletul ajunge în FANbox, FAN Courier îți trimite prin SMS codul de deschidere.',
            'address' => 'Curierul te poate contacta telefonic în ziua livrării — ține telefonul aproape.',
        ],
        'cod_note' => [
            'easybox' => 'Plătești la ridicarea coletului, cu cardul, direct pe ecranul easybox-ului.',
            'pudo' => 'Plătești la ridicarea coletului de la punctul Sameday.',
            'fanbox' => 'Plătești la ridicarea coletului, cu cardul, direct la FANbox.',
            'address' => 'Plătești curierului la livrare — numerar sau card, dacă curierul are POS.',
        ],
        'step_delivered' => [
            'easybox' => 'Ridici coletul din easybox',
            'pudo' => 'Ridici coletul de la punctul Sameday',
            'fanbox' => 'Ridici coletul din FANbox',
            'address' => 'Curierul îți aduce coletul',
        ],
        'hours' => 'Luni – Vineri, 08:00 – 17:00',
    ];

    /** @var Order */
    private $order;
    /** @var LockermailFix */
    private $module;
    /** @var Context */
    private $context;
    /** @var Currency */
    private $currency;
    private $taxExcluded = false;

    public function __construct(Order $order, $module)
    {
        $this->order = $order;
        $this->module = $module;
        $this->context = Context::getContext();
        $this->currency = new Currency((int) $order->id_currency);
        $this->taxExcluded = (int) Product::getTaxCalculationMethod((int) $order->id_customer) === (int) PS_TAX_EXC;
    }

    /**
     * @return array variabile {lmf_*} pentru șablon
     */
    public function buildVars()
    {
        $delivery = $this->getDeliveryInfo();
        $payment = $this->getPaymentInfo($delivery['type']);
        $customer = new Customer((int) $this->order->id_customer);

        $trackUrl = $this->context->link->getPageLink(
            (Validate::isLoadedObject($customer) && $customer->is_guest) ? 'guest-tracking' : 'history',
            true,
            (int) $this->order->id_lang,
            null,
            false,
            (int) $this->order->id_shop
        );

        $preheader = 'Comanda ' . $this->order->reference . ' · ' . $delivery['short'] . ' · ' . $payment['short'];

        return [
            '{lmf_preheader}' => $this->e($preheader),
            '{lmf_status_html}' => $this->statusHtml($payment),
            '{lmf_meta_html}' => $this->metaHtml(),
            '{lmf_delivery_html}' => $this->deliveryHtml($delivery),
            '{lmf_payment_html}' => $this->paymentHtml($payment),
            '{lmf_products_html}' => $this->productsHtml(),
            '{lmf_totals_html}' => $this->totalsHtml($payment),
            '{lmf_steps_html}' => $this->stepsHtml($delivery, $payment),
            '{lmf_contact_html}' => $this->contactHtml(),
            '{lmf_track_url}' => $this->e($trackUrl),
            '{lmf_delivery_txt}' => $this->deliveryTxt($delivery),
            '{lmf_payment_txt}' => $this->paymentTxt($payment),
            '{lmf_products_txt}' => $this->productsTxt(),
            '{lmf_totals_txt}' => $this->totalsTxt($payment),
            '{lmf_contact_txt}' => $this->contactTxt(),
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Date                                                               */
    /* ------------------------------------------------------------------ */

    private function getDeliveryInfo()
    {
        $order = $this->order;
        $record = $this->module->getRecord((int) $order->id);
        $locker = null;
        $type = 'address';

        if ($record && $record['delivery_type'] !== 'address') {
            $type = $record['delivery_type'];
            $locker = $record;
        } else {
            $live = $this->module->detectLocker($order);
            if ($live) {
                $type = $live['delivery_type'];
                $locker = $live;
            }
        }
        if (!isset(self::$texts['delivery_title'][$type])) {
            $type = 'address';
        }

        $address = new Address((int) $order->id_address_delivery);
        $orig = ($record && (int) $record['id_address_original']) ? new Address((int) $record['id_address_original']) : $address;
        $carrier = new Carrier((int) $order->id_carrier, (int) $order->id_lang);

        $recipient = trim($address->firstname . ' ' . $address->lastname);
        $phone = $address->phone_mobile ?: $address->phone;
        if (!$phone && Validate::isLoadedObject($orig)) {
            $phone = $orig->phone_mobile ?: $orig->phone;
        }

        $lines = [];
        if ($locker) {
            $lines[] = ['strong' => true, 'text' => $locker['locker_name']];
            if ($locker['locker_address'] !== '') {
                $lines[] = ['strong' => false, 'text' => $locker['locker_address']];
            }
            $cityLine = trim(implode(', ', array_filter([$locker['locker_city'], $locker['locker_county']])) . ' ' . $locker['locker_postcode']);
            if ($cityLine !== '') {
                $lines[] = ['strong' => false, 'text' => $cityLine];
            }
        } else {
            if ($address->company) {
                $lines[] = ['strong' => true, 'text' => $address->company];
            }
            $lines[] = ['strong' => !$address->company, 'text' => trim($address->address1 . ' ' . $address->address2)];
            $state = $address->id_state ? new State((int) $address->id_state) : null;
            $lines[] = ['strong' => false, 'text' => trim($address->postcode . ' ' . $address->city . ($state && Validate::isLoadedObject($state) ? ', jud. ' . $state->name : ''))];
        }

        $shortPlace = $locker ? $locker['locker_name'] : $address->city;

        return [
            'type' => $type,
            'title' => self::$texts['delivery_title'][$type],
            'note' => self::$texts['delivery_note'][$type],
            'lines' => $lines,
            'recipient' => $recipient,
            'phone' => (string) $phone,
            'carrier' => Validate::isLoadedObject($carrier) ? $carrier->name : '',
            'courier' => $locker && !empty($locker['courier']) ? $locker['courier'] : (Validate::isLoadedObject($carrier) ? $carrier->name : 'Curierul'),
            'short' => ($type === 'address' ? 'Livrare la adresă, ' : self::$texts['delivery_title'][$type] . ': ') . $shortPlace,
        ];
    }

    private function getPaymentInfo($deliveryType)
    {
        $order = $this->order;
        $state = new OrderState((int) $order->current_state, (int) $order->id_lang);
        $paid = $order->hasBeenPaid() || (Validate::isLoadedObject($state) && (int) $state->paid === 1);

        $module = Tools::strtolower((string) $order->module);
        $label = Tools::strtolower((string) $order->payment);

        $isCod = strpos($module, 'cashondelivery') !== false || strpos($module, 'ramburs') !== false
            || in_array($module, ['cod', 'codfee', 'ps_codfee'], true) || strpos($label, 'ramburs') !== false
            || strpos($label, 'la livrare') !== false;
        $isWire = strpos($module, 'wirepayment') !== false || strpos($module, 'bankwire') !== false
            || strpos($label, 'transfer') !== false || strpos($label, 'ordin de plat') !== false;

        if ($paid) {
            $status = self::PAY_PAID;
        } elseif ($isCod) {
            $status = self::PAY_COD;
        } elseif ($isWire) {
            $status = self::PAY_WIRE;
        } else {
            $status = self::PAY_PENDING;
        }

        $total = $this->price($order->total_paid_tax_incl);
        $method = trim((string) $order->payment);

        $info = [
            'status' => $status,
            'method' => $method,
            'total' => $total,
            'note' => '',
            'bank' => [],
        ];

        switch ($status) {
            case self::PAY_PAID:
                $info['badge'] = 'Plătită';
                $info['headline'] = 'Plata a fost confirmată';
                $info['short'] = 'Plătită';
                break;
            case self::PAY_COD:
                $info['badge'] = 'Plată la livrare';
                $info['headline'] = 'De plată la livrare: ' . $total;
                $info['note'] = self::$texts['cod_note'][$deliveryType] ?? self::$texts['cod_note']['address'];
                $info['short'] = 'De plată la livrare ' . $total;
                break;
            case self::PAY_WIRE:
                $info['badge'] = 'Așteaptă plata';
                $info['headline'] = 'De plătit prin transfer: ' . $total;
                $info['note'] = 'Pregătim coletul imediat ce primim plata. Te rugăm să treci la detaliile plății numărul comenzii: ' . $order->reference . '.';
                $info['bank'] = array_filter([
                    'Beneficiar' => (string) Configuration::get('BANK_WIRE_OWNER', null, null, (int) $order->id_shop),
                    'Detalii cont' => (string) Configuration::get('BANK_WIRE_DETAILS', null, null, (int) $order->id_shop),
                    'Adresa băncii' => (string) Configuration::get('BANK_WIRE_ADDRESS', null, null, (int) $order->id_shop),
                    'Detalii plată' => 'Comanda ' . $order->reference,
                ], function ($v) { return trim($v) !== ''; });
                $info['short'] = 'De plătit prin transfer ' . $total;
                break;
            default:
                $info['badge'] = 'Plată în curs de confirmare';
                $info['headline'] = 'Plata este în curs de confirmare';
                $info['note'] = 'Îți scriem imediat ce plata este confirmată.';
                $info['short'] = 'Plată în curs de confirmare';
        }

        return $info;
    }

    /* ------------------------------------------------------------------ */
    /*  HTML                                                               */
    /* ------------------------------------------------------------------ */

    private function statusHtml(array $p)
    {
        $ok = $p['status'] === self::PAY_PAID;

        return '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>'
            . $this->pill('✓ Comandă primită', self::C_OK, self::C_OK_BG)
            . '<td width="8" style="font-size:0;line-height:0;">&nbsp;</td>'
            . $this->pill(($ok ? '✓ ' : '') . $p['badge'], $ok ? self::C_OK : self::C_WARN, $ok ? self::C_OK_BG : self::C_WARN_BG)
            . '</tr></table>';
    }

    private function pill($text, $color, $bg)
    {
        return '<td style="background:' . $bg . ';border-radius:999px;padding:6px 12px;font-family:' . self::FONT
            . ';font-size:13px;font-weight:bold;color:' . $color . ';white-space:nowrap;">' . $this->e($text) . '</td>';
    }

    private function metaHtml()
    {
        $o = $this->order;
        $date = Tools::displayDate($o->date_add, false);
        $cells = [
            ['Nr. comandă', $o->reference],
            ['Data', $date],
            ['Total', $this->price($o->total_paid_tax_incl)],
        ];
        $html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid ' . self::C_BORDER . ';border-radius:8px;"><tr>';
        foreach ($cells as $i => $c) {
            $html .= '<td width="33%" style="padding:12px 14px;' . ($i ? 'border-left:1px solid ' . self::C_BORDER . ';' : '') . 'font-family:' . self::FONT . ';vertical-align:top;">'
                . '<div style="font-size:12px;color:' . self::C_MUTED . ';">' . $this->e($c[0]) . '</div>'
                . '<div style="font-size:15px;font-weight:bold;color:' . self::C_TEXT . ';padding-top:2px;">' . $this->e($c[1]) . '</div></td>';
        }

        return $html . '</tr></table>';
    }

    private function sectionTitle($text)
    {
        return '<div style="font-family:' . self::FONT . ';font-size:12px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:' . self::C_MUTED . ';padding:0 0 8px;">' . $this->e($text) . '</div>';
    }

    private function deliveryHtml(array $d)
    {
        $html = $this->sectionTitle('Unde vine coletul');
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid ' . self::C_BORDER . ';border-left:4px solid ' . self::C_ACCENT . ';border-radius:8px;"><tr><td style="padding:16px 18px;font-family:' . self::FONT . ';color:' . self::C_TEXT . ';">';
        $html .= '<div style="font-size:17px;font-weight:bold;padding-bottom:8px;">' . $this->e($d['title']) . '</div>';
        foreach ($d['lines'] as $l) {
            if (trim($l['text']) === '') {
                continue;
            }
            $html .= '<div style="font-size:15px;line-height:22px;' . ($l['strong'] ? 'font-weight:bold;' : '') . '">' . $this->e($l['text']) . '</div>';
        }
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:12px;"><tr><td style="border-top:1px solid ' . self::C_BORDER . ';padding-top:10px;font-family:' . self::FONT . ';font-size:14px;line-height:21px;color:' . self::C_TEXT . ';">'
            . '<span style="color:' . self::C_MUTED . ';">Destinatar:</span> <b>' . $this->e($d['recipient']) . '</b>'
            . ($d['phone'] !== '' ? ' · ' . $this->e($d['phone']) : '')
            . ($d['carrier'] !== '' ? '<br><span style="color:' . self::C_MUTED . ';">Curier:</span> ' . $this->e($d['carrier']) : '')
            . '</td></tr></table>';
        $html .= '<div style="margin-top:12px;background:' . self::C_BG_SOFT . ';border-radius:6px;padding:10px 12px;font-size:13px;line-height:20px;color:' . self::C_MUTED . ';">' . $this->e($d['note']) . '</div>';

        return $html . '</td></tr></table>';
    }

    private function paymentHtml(array $p)
    {
        $ok = $p['status'] === self::PAY_PAID;
        $color = $ok ? self::C_OK : self::C_WARN;
        $bg = $ok ? self::C_OK_BG : self::C_WARN_BG;

        $html = $this->sectionTitle('Plata');
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:' . $bg . ';border-radius:8px;"><tr><td style="padding:16px 18px;font-family:' . self::FONT . ';color:' . self::C_TEXT . ';">';
        $html .= '<div style="font-size:17px;font-weight:bold;color:' . $color . ';">' . ($ok ? '✓ ' : '') . $this->e($p['headline']) . '</div>';
        $html .= '<div style="font-size:14px;line-height:21px;padding-top:4px;"><span style="color:' . self::C_MUTED . ';">Metoda:</span> ' . $this->e($p['method']) . '</div>';
        if ($p['note'] !== '') {
            $html .= '<div style="font-size:14px;line-height:21px;padding-top:8px;">' . $this->e($p['note']) . '</div>';
        }
        if ($p['bank']) {
            $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:12px;background:#ffffff;border:1px solid ' . self::C_BORDER . ';border-radius:6px;">';
            foreach ($p['bank'] as $k => $v) {
                $html .= '<tr><td style="padding:8px 12px;font-family:' . self::FONT . ';font-size:13px;color:' . self::C_MUTED . ';vertical-align:top;width:35%;">' . $this->e($k) . '</td>'
                    . '<td style="padding:8px 12px;font-family:' . self::FONT . ';font-size:14px;font-weight:bold;color:' . self::C_TEXT . ';">' . nl2br($this->e($v)) . '</td></tr>';
            }
            $html .= '</table>';
        }

        return $html . '</td></tr></table>';
    }

    private function getProductRows()
    {
        $rows = [];
        $idLang = (int) $this->order->id_lang;
        $imageType = 'small_default';
        try {
            if (class_exists('ImageType') && method_exists('ImageType', 'getFormattedName')) {
                $imageType = ImageType::getFormattedName('small');
            }
        } catch (\Throwable $e) {
        }

        foreach ($this->order->getProducts() as $p) {
            $img = '';
            try {
                $idImage = 0;
                if (isset($p['image']) && $p['image'] instanceof Image && $p['image']->id) {
                    $idImage = (int) $p['image']->id;
                } else {
                    $cover = Image::getCover((int) $p['product_id']);
                    $idImage = $cover ? (int) $cover['id_image'] : 0;
                }
                if ($idImage) {
                    $rewrite = Db::getInstance()->getValue('SELECT `link_rewrite` FROM `' . _DB_PREFIX_ . 'product_lang`
                        WHERE `id_product` = ' . (int) $p['product_id'] . ' AND `id_lang` = ' . $idLang . ' AND `id_shop` = ' . (int) $this->order->id_shop);
                    $img = $this->context->link->getImageLink($rewrite ?: 'produs', (int) $p['product_id'] . '-' . $idImage, $imageType);
                    if (strpos($img, '//') === 0) {
                        $img = 'https:' . $img;
                    }
                }
            } catch (\Throwable $e) {
                $img = '';
            }

            $rows[] = [
                'name' => (string) $p['product_name'],
                'reference' => (string) $p['product_reference'],
                'qty' => (int) $p['product_quantity'],
                'unit' => $this->price($this->taxExcluded ? $p['unit_price_tax_excl'] : $p['unit_price_tax_incl']),
                'total' => $this->price($this->taxExcluded ? $p['total_price_tax_excl'] : $p['total_price_tax_incl']),
                'img' => $img,
            ];
        }

        return $rows;
    }

    private function productsHtml()
    {
        $html = $this->sectionTitle('Ce ai comandat');
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">';
        foreach ($this->getProductRows() as $i => $r) {
            $border = 'border-top:1px solid ' . self::C_BORDER . ';';
            $html .= '<tr>';
            $html .= '<td width="64" style="' . $border . 'padding:12px 12px 12px 0;vertical-align:top;">'
                . ($r['img']
                    ? '<img src="' . $this->e($r['img']) . '" width="64" height="64" alt="" style="display:block;width:64px;height:64px;object-fit:contain;border:1px solid ' . self::C_BORDER . ';border-radius:6px;background:#ffffff;">'
                    : '<div style="width:64px;height:64px;background:' . self::C_BG_SOFT . ';border:1px solid ' . self::C_BORDER . ';border-radius:6px;"></div>')
                . '</td>';
            $html .= '<td style="' . $border . 'padding:12px 0;vertical-align:top;font-family:' . self::FONT . ';">'
                . '<div style="font-size:15px;line-height:21px;font-weight:bold;color:' . self::C_TEXT . ';">' . $this->e($r['name']) . '</div>'
                . ($r['reference'] !== '' ? '<div style="font-size:12px;color:' . self::C_MUTED . ';padding-top:2px;">Cod: ' . $this->e($r['reference']) . '</div>' : '')
                . '<div style="font-size:13px;color:' . self::C_MUTED . ';padding-top:4px;">' . $r['qty'] . ' × ' . $this->e($r['unit']) . '</div>'
                . '</td>';
            $html .= '<td align="right" style="' . $border . 'padding:12px 0 12px 12px;vertical-align:top;font-family:' . self::FONT . ';font-size:15px;font-weight:bold;color:' . self::C_TEXT . ';white-space:nowrap;">' . $this->e($r['total']) . '</td>';
            $html .= '</tr>';
        }

        return $html . '</table>';
    }

    private function getTotals(array $p)
    {
        $o = $this->order;
        $ex = $this->taxExcluded;
        $lines = [];
        $lines[] = ['Produse', $this->price($ex ? $o->total_products : $o->total_products_wt)];

        $discount = $ex ? (float) $o->total_discounts_tax_excl : (float) $o->total_discounts_tax_incl;
        if ($discount > 0) {
            $names = [];
            foreach ((array) $o->getCartRules() as $cr) {
                $names[] = $cr['name'];
            }
            $lines[] = ['Reducere' . ($names ? ' (' . implode(', ', $names) . ')' : ''), '−' . $this->price($discount)];
        }

        $wrap = $ex ? (float) $o->total_wrapping_tax_excl : (float) $o->total_wrapping_tax_incl;
        if ($wrap > 0) {
            $lines[] = ['Ambalare cadou', $this->price($wrap)];
        }

        $ship = $ex ? (float) $o->total_shipping_tax_excl : (float) $o->total_shipping_tax_incl;
        $lines[] = ['Livrare', $ship > 0 ? $this->price($ship) : 'Gratuită'];

        $labels = [
            self::PAY_PAID => 'Total plătit',
            self::PAY_COD => 'Total de plată la livrare',
            self::PAY_WIRE => 'Total de plătit prin transfer',
            self::PAY_PENDING => 'Total comandă',
        ];
        $tax = (float) $o->total_paid_tax_incl - (float) $o->total_paid_tax_excl;

        return [
            'lines' => $lines,
            'total_label' => $labels[$p['status']],
            'total' => $this->price($o->total_paid_tax_incl),
            'tax' => $tax > 0 ? 'din care TVA ' . $this->price($tax) : '',
            'ex_note' => $ex ? 'Prețurile produselor sunt afișate fără TVA.' : '',
        ];
    }

    private function totalsHtml(array $p)
    {
        $t = $this->getTotals($p);
        $html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top:2px solid ' . self::C_TEXT . ';">';
        foreach ($t['lines'] as $l) {
            $html .= '<tr><td style="padding:8px 0 0;font-family:' . self::FONT . ';font-size:14px;color:' . self::C_MUTED . ';">' . $this->e($l[0]) . '</td>'
                . '<td align="right" style="padding:8px 0 0;font-family:' . self::FONT . ';font-size:14px;color:' . self::C_TEXT . ';white-space:nowrap;">' . $this->e($l[1]) . '</td></tr>';
        }
        $html .= '<tr><td style="padding:14px 0 0;font-family:' . self::FONT . ';font-size:17px;font-weight:bold;color:' . self::C_TEXT . ';">' . $this->e($t['total_label']) . '</td>'
            . '<td align="right" style="padding:14px 0 0;font-family:' . self::FONT . ';font-size:20px;font-weight:bold;color:' . self::C_TEXT . ';white-space:nowrap;">' . $this->e($t['total']) . '</td></tr>';
        if ($t['tax'] !== '' || $t['ex_note'] !== '') {
            $html .= '<tr><td colspan="2" align="right" style="padding:2px 0 0;font-family:' . self::FONT . ';font-size:12px;color:' . self::C_MUTED . ';">'
                . $this->e(trim($t['tax'] . ($t['ex_note'] ? ' · ' . $t['ex_note'] : ''), ' ·')) . '</td></tr>';
        }

        return $html . '</table>';
    }

    private function stepsHtml(array $d, array $p)
    {
        $steps = [['Comandă primită', 'Am înregistrat comanda și ți-am trimis acest email.', true]];
        if ($p['status'] === self::PAY_WIRE) {
            $steps[] = ['Așteptăm plata', 'Pregătim coletul imediat ce primim transferul.', false];
        }
        $steps[] = ['Pregătim coletul', 'Verificăm produsele și împachetăm comanda.', false];
        $steps[] = ['Predăm coletul curierului', $d['courier'] . ' te anunță prin SMS / email când coletul e pe drum.', false];
        $steps[] = [self::$texts['step_delivered'][$d['type']], $p['status'] === self::PAY_COD ? 'Plătești ' . $p['total'] . ' la livrare.' : 'Spor la montaj!', false];

        $html = $this->sectionTitle('Ce urmează');
        $html .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">';
        $n = count($steps);
        foreach ($steps as $i => $s) {
            $done = $s[2];
            $html .= '<tr>'
                . '<td width="36" style="vertical-align:top;padding:0 12px ' . ($i < $n - 1 ? '14' : '0') . 'px 0;">'
                . '<div style="width:28px;height:28px;border-radius:14px;text-align:center;box-sizing:border-box;'
                . ($done ? 'background:' . self::C_OK . ';color:#ffffff;line-height:28px;' : 'background:#ffffff;border:2px solid ' . self::C_BORDER . ';color:' . self::C_MUTED . ';line-height:24px;')
                . 'font-family:' . self::FONT . ';font-size:13px;font-weight:bold;">' . ($done ? '✓' : ($i + 1)) . '</div></td>'
                . '<td style="vertical-align:top;padding:3px 0 ' . ($i < $n - 1 ? '14' : '0') . 'px;font-family:' . self::FONT . ';">'
                . '<div style="font-size:15px;font-weight:bold;color:' . ($done ? self::C_OK : self::C_TEXT) . ';">' . $this->e($s[0]) . '</div>'
                . '<div style="font-size:13px;line-height:19px;color:' . self::C_MUTED . ';padding-top:2px;">' . $this->e($s[1]) . '</div>'
                . '</td></tr>';
        }

        return $html . '</table>';
    }

    private function contactHtml()
    {
        $phone = (string) Configuration::get('PS_SHOP_PHONE', null, null, (int) $this->order->id_shop);
        $email = (string) Configuration::get('PS_SHOP_EMAIL', null, null, (int) $this->order->id_shop);
        $parts = [];
        if ($phone !== '') {
            $tel = preg_replace('/[^0-9+]/', '', $phone);
            $parts[] = 'Sună-ne la <a href="tel:' . $this->e($tel) . '" style="color:' . self::C_ACCENT . ';font-weight:bold;text-decoration:none;">' . $this->e($phone) . '</a>';
        }
        if ($email !== '') {
            $parts[] = 'scrie-ne la <a href="mailto:' . $this->e($email) . '" style="color:' . self::C_ACCENT . ';font-weight:bold;text-decoration:none;">' . $this->e($email) . '</a>';
        }
        $parts[] = 'sau răspunde direct la acest email.';

        return '<div style="font-family:' . self::FONT . ';font-size:15px;font-weight:bold;color:' . self::C_TEXT . ';">Ai o întrebare despre comandă?</div>'
            . '<div style="font-family:' . self::FONT . ';font-size:14px;line-height:22px;color:' . self::C_TEXT . ';padding-top:4px;">' . implode(', ', $parts) . '</div>'
            . '<div style="font-family:' . self::FONT . ';font-size:13px;color:' . self::C_MUTED . ';padding-top:4px;">Program: ' . $this->e(self::$texts['hours']) . '. Ține la îndemână numărul comenzii: <b>' . $this->e($this->order->reference) . '</b>.</div>';
    }

    /* ------------------------------------------------------------------ */
    /*  Text simplu                                                        */
    /* ------------------------------------------------------------------ */

    private function deliveryTxt(array $d)
    {
        $out = mb_strtoupper('Unde vine coletul') . "\n" . $d['title'] . "\n";
        foreach ($d['lines'] as $l) {
            if (trim($l['text']) !== '') {
                $out .= $l['text'] . "\n";
            }
        }
        $out .= 'Destinatar: ' . $d['recipient'] . ($d['phone'] !== '' ? ', ' . $d['phone'] : '') . "\n";
        if ($d['carrier'] !== '') {
            $out .= 'Curier: ' . $d['carrier'] . "\n";
        }

        return $out . $d['note'];
    }

    private function paymentTxt(array $p)
    {
        $out = "PLATA\n" . $p['headline'] . "\nMetoda: " . $p['method'];
        if ($p['note'] !== '') {
            $out .= "\n" . $p['note'];
        }
        foreach ($p['bank'] as $k => $v) {
            $out .= "\n" . $k . ': ' . preg_replace('/\s*\n\s*/', ', ', trim($v));
        }

        return $out;
    }

    private function productsTxt()
    {
        $out = "CE AI COMANDAT\n";
        foreach ($this->getProductRows() as $r) {
            $out .= '- ' . $r['name'] . ($r['reference'] !== '' ? ' (cod ' . $r['reference'] . ')' : '') . ' — ' . $r['qty'] . ' × ' . $r['unit'] . ' = ' . $r['total'] . "\n";
        }

        return rtrim($out);
    }

    private function totalsTxt(array $p)
    {
        $t = $this->getTotals($p);
        $out = '';
        foreach ($t['lines'] as $l) {
            $out .= $l[0] . ': ' . $l[1] . "\n";
        }
        $out .= mb_strtoupper($t['total_label']) . ': ' . $t['total'];
        if ($t['tax'] !== '') {
            $out .= ' (' . $t['tax'] . ')';
        }

        return $out;
    }

    private function contactTxt()
    {
        $phone = (string) Configuration::get('PS_SHOP_PHONE', null, null, (int) $this->order->id_shop);
        $email = (string) Configuration::get('PS_SHOP_EMAIL', null, null, (int) $this->order->id_shop);

        return 'Întrebări? ' . trim(($phone ? 'Telefon: ' . $phone . '  ' : '') . ($email ? 'Email: ' . $email : ''))
            . "\nProgram: " . self::$texts['hours'];
    }

    /* ------------------------------------------------------------------ */

    private function price($amount)
    {
        try {
            return Tools::getContextLocale($this->context)->formatPrice((float) $amount, $this->currency->iso_code);
        } catch (\Throwable $e) {
            return number_format((float) $amount, 2, ',', '.') . ' ' . $this->currency->iso_code;
        }
    }

    private function e($s)
    {
        return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
    }
}
