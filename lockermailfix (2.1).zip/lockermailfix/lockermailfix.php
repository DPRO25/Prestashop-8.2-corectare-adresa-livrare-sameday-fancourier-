<?php
/**
 * Module: lockermailfix
 * Adresa de livrare corectă pentru comenzile cu Sameday easybox / PUDO și FAN Courier FANbox — PrestaShop 8.x
 *
 * v2.1.0
 *  - Email de confirmare a comenzii modern (mails/ro/order_conf.html): unde vine coletul (easybox / FANbox / adresă),
 *    starea plății (plătită / ramburs / transfer), produse cu imagine, pași următori. Se activează/dezactivează din
 *    configurare; cu modulul dezactivat se trimite automat șablonul standard PrestaShop.
 *
 * v2.0.0
 *  - Sameday: citește lockerul din ps_cart.sameday_locker (salvat la alegerea pe hartă), deci NU mai
 *    depinde de ordinea hook-urilor; fallback pe ps_sameday_order_locker.
 *  - Verifică serviciul Sameday al curierului comenzii (LN/XL/PP/XP) — nu mai aplică un locker vechi
 *    rămas în coș pe o comandă cu livrare la adresă.
 *  - FAN Courier: detectează automat coloanele din ps_fancourier_order_info.
 *  - NU mai modifică niciodată adresele clientului: creează o adresă nouă, doar pentru comandă
 *    (ascunsă din agenda clientului), și o pune ca adresă de livrare.
 *  - Elimină UPDATE-ul pe ps_order_carrier.id_address_delivery (coloana nu există).
 *  - Tot codul rulează în try/catch: o eroare a modulului nu poate bloca plasarea comenzii.
 *  - BO: panou „Livrare” în pagina comenzii + coloană „Livrare” în lista de comenzi.
 *  - Pagină de configurare cu diagnostic și reparare comenzi vechi.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class LockermailFix extends Module
{
    const TABLE = 'lockermailfix_order';

    const TYPE_ADDRESS = 'address';
    const TYPE_EASYBOX = 'easybox';
    const TYPE_PUDO = 'pudo';
    const TYPE_FANBOX = 'fanbox';

    /** Coduri servicii Sameday care livrează la locker / punct (vezi SamedayConstants) */
    const SAMEDAY_EASYBOX_CODES = ['LN', 'XL'];
    const SAMEDAY_PUDO_CODES = ['PP', 'XP'];

    /** @var array cache existență tabele / coloane */
    private $schemaCache = [];

    /** @var bool variabilele emailului order_conf au fost pregătite pentru emailul curent */
    private $mailPending = false;

    public function __construct()
    {
        $this->name = 'lockermailfix';
        $this->tab = 'shipping_logistics';
        $this->version = '2.1.0';
        $this->author = 'DPRO25';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Locker Mail Fix');
        $this->description = $this->l('Pune adresa easybox / FANbox aleasă ca adresă de livrare a comenzii (email, BO, factură) și arată tipul livrării în BO.');
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => _PS_VERSION_];
    }

    /* ------------------------------------------------------------------ */
    /*  Instalare                                                          */
    /* ------------------------------------------------------------------ */

    public function getHookList()
    {
        return [
            'actionValidateOrder',
            'actionValidateOrderAfter',
            'displayAdminOrderTop',
            'actionOrderGridDefinitionModifier',
            'actionOrderGridQueryBuilderModifier',
            'actionEmailSendBefore',
            'actionEmailAddAfterContent',
        ];
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->registerHook($this->getHookList())
            && $this->moveHookToLast('actionValidateOrder')
            && Configuration::updateValue('LMF_REPLACE_ADDRESS', 1)
            && Configuration::updateValue('LMF_FAN_CARRIERS', '')
            && Configuration::updateValue('LMF_MAIL_ENABLED', 1);
    }

    public function uninstall()
    {
        // Tabelul cu istoricul NU se șterge intenționat (comenzile rămân legate de adresele create).
        Configuration::deleteByName('LMF_REPLACE_ADDRESS');
        Configuration::deleteByName('LMF_FAN_CARRIERS');
        Configuration::deleteByName('LMF_MAIL_ENABLED');

        return parent::uninstall();
    }

    public function installDb()
    {
        return Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . self::TABLE . '` (
                `id_order` INT(10) UNSIGNED NOT NULL,
                `id_cart` INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `courier` VARCHAR(32) NOT NULL DEFAULT \'\',
                `delivery_type` VARCHAR(16) NOT NULL DEFAULT \'address\',
                `delivery_label` VARCHAR(255) NOT NULL DEFAULT \'\',
                `locker_id` VARCHAR(64) NOT NULL DEFAULT \'\',
                `locker_name` VARCHAR(255) NOT NULL DEFAULT \'\',
                `locker_address` VARCHAR(255) NOT NULL DEFAULT \'\',
                `locker_city` VARCHAR(64) NOT NULL DEFAULT \'\',
                `locker_county` VARCHAR(64) NOT NULL DEFAULT \'\',
                `locker_postcode` VARCHAR(12) NOT NULL DEFAULT \'\',
                `source` VARCHAR(64) NOT NULL DEFAULT \'\',
                `id_address_original` INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `id_address_new` INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `reverted` TINYINT(1) NOT NULL DEFAULT 0,
                `error` VARCHAR(255) NOT NULL DEFAULT \'\',
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_order`),
                KEY `id_cart` (`id_cart`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;
        ');
    }

    /**
     * Pune modulul ultimul pe hook, ca toate modulele de curierat să-și fi salvat datele înainte.
     */
    public function moveHookToLast($hookName)
    {
        $idHook = (int) Hook::getIdByName($hookName);
        if (!$idHook || !$this->id) {
            return true;
        }
        $db = Db::getInstance();
        $rows = $db->executeS('SELECT `id_shop` FROM `' . _DB_PREFIX_ . 'hook_module`
            WHERE `id_hook` = ' . $idHook . ' AND `id_module` = ' . (int) $this->id);
        foreach ((array) $rows as $row) {
            $idShop = (int) $row['id_shop'];
            $max = (int) $db->getValue('SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . 'hook_module`
                WHERE `id_hook` = ' . $idHook . ' AND `id_shop` = ' . $idShop);
            $db->execute('UPDATE `' . _DB_PREFIX_ . 'hook_module` SET `position` = ' . ($max + 1) . '
                WHERE `id_hook` = ' . $idHook . ' AND `id_shop` = ' . $idShop . ' AND `id_module` = ' . (int) $this->id);
        }

        return true;
    }

    /* ------------------------------------------------------------------ */
    /*  Hook-uri comandă                                                   */
    /* ------------------------------------------------------------------ */

    /**
     * Rulează înainte de emailul de confirmare (PaymentModule reîncarcă comanda după acest hook,
     * deci emailul și factura iau noua adresă de livrare).
     */
    public function hookActionValidateOrder($params)
    {
        try {
            if (isset($params['order']) && $params['order'] instanceof Order) {
                $cart = (isset($params['cart']) && $params['cart'] instanceof Cart) ? $params['cart'] : null;
                $this->processOrder($params['order'], $cart);
            }
        } catch (\Throwable $e) {
            $this->log('actionValidateOrder: ' . $e->getMessage(), 3, isset($params['order']->id) ? (int) $params['order']->id : 0);
        }
    }

    /**
     * A doua încercare, după ce toate modulele au terminat (prinde module care scriu lockerul târziu).
     */
    public function hookActionValidateOrderAfter($params)
    {
        try {
            $orders = [];
            if (!empty($params['orders']) && is_array($params['orders'])) {
                $orders = $params['orders'];
            } elseif (isset($params['order']) && $params['order'] instanceof Order) {
                $orders = [$params['order']];
            }
            foreach ($orders as $order) {
                if ($order instanceof Order && Validate::isLoadedObject($order)) {
                    $this->processOrder(new Order((int) $order->id));
                }
            }
        } catch (\Throwable $e) {
            $this->log('actionValidateOrderAfter: ' . $e->getMessage(), 3);
        }
    }

    /**
     * Procesează o comandă. Idempotent: dacă adresa a fost deja înlocuită, nu face nimic.
     *
     * @return array|null rândul din tabelul modulului
     */
    public function processOrder(Order $order, Cart $cart = null)
    {
        if (!Validate::isLoadedObject($order)) {
            return null;
        }
        $idOrder = (int) $order->id;
        $existing = $this->getRecord($idOrder);

        if ($existing && ((int) $existing['id_address_new'] > 0 || (int) $existing['reverted'] === 1)) {
            return $existing;
        }

        $locker = $this->detectLocker($order, $cart);

        $record = [
            'id_order' => $idOrder,
            'id_cart' => (int) $order->id_cart,
            'courier' => '',
            'delivery_type' => self::TYPE_ADDRESS,
            'delivery_label' => 'Adresă',
            'locker_id' => '',
            'locker_name' => '',
            'locker_address' => '',
            'locker_city' => '',
            'locker_county' => '',
            'locker_postcode' => '',
            'source' => '',
            'id_address_original' => $existing ? (int) $existing['id_address_original'] : (int) $order->id_address_delivery,
            'id_address_new' => 0,
            'reverted' => 0,
            'error' => '',
        ];
        if (!$record['id_address_original']) {
            $record['id_address_original'] = (int) $order->id_address_delivery;
        }

        if ($locker) {
            foreach ($locker as $k => $v) {
                if (array_key_exists($k, $record)) {
                    $record[$k] = $v;
                }
            }

            if (Configuration::get('LMF_REPLACE_ADDRESS')) {
                $error = '';
                $newId = $this->createLockerAddress((int) $record['id_address_original'], $locker, $error);
                if ($newId) {
                    $this->setOrderDeliveryAddress($order, $newId);
                    $record['id_address_new'] = $newId;
                    $this->log('Comanda ' . $idOrder . ': adresa de livrare setată pe ' . $locker['delivery_label']
                        . ' (id_address ' . $record['id_address_original'] . ' → ' . $newId . ')', 1, $idOrder);
                } else {
                    $record['error'] = Tools::substr($error, 0, 255);
                    $this->log('Comanda ' . $idOrder . ': nu am putut crea adresa locker: ' . $error, 2, $idOrder);
                }
            }
        }

        $this->saveRecord($record);

        return $this->getRecord($idOrder);
    }

    /**
     * Readuce comanda pe adresa inițială a clientului.
     */
    public function revertOrder($idOrder)
    {
        $rec = $this->getRecord((int) $idOrder);
        if (!$rec || !(int) $rec['id_address_original']) {
            return false;
        }
        Db::getInstance()->update('orders', ['id_address_delivery' => (int) $rec['id_address_original']], 'id_order = ' . (int) $idOrder);
        Db::getInstance()->update(self::TABLE, ['id_address_new' => 0, 'reverted' => 1, 'date_upd' => date('Y-m-d H:i:s')], 'id_order = ' . (int) $idOrder);

        return true;
    }

    /**
     * Forțează re-aplicarea (după revert sau după o eroare).
     */
    public function reapplyOrder($idOrder)
    {
        Db::getInstance()->update(self::TABLE, ['reverted' => 0, 'id_address_new' => 0], 'id_order = ' . (int) $idOrder);
        $order = new Order((int) $idOrder);

        return $this->processOrder($order);
    }

    /* ------------------------------------------------------------------ */
    /*  Detecție locker                                                    */
    /* ------------------------------------------------------------------ */

    /**
     * @return array|null
     */
    public function detectLocker(Order $order, Cart $cart = null)
    {
        $locker = $this->detectSameday($order, $cart);
        if (!$locker) {
            $locker = $this->detectFan($order);
        }

        return $locker;
    }

    /**
     * Codul serviciului Sameday asociat curierului comenzii, sau null dacă nu e curier Sameday.
     */
    private function getSamedayServiceCode($idCarrier)
    {
        if (!$this->tableExists('sameday_services')) {
            return null;
        }
        $live = (int) Configuration::get('SAMEDAY_LIVE_MODE');
        $rows = Db::getInstance()->executeS('SELECT `code`, `live_mode` FROM `' . _DB_PREFIX_ . 'sameday_services`
            WHERE `id_carrier` = ' . (int) $idCarrier);
        if (!$rows) {
            return null;
        }
        foreach ($rows as $row) {
            if ((int) $row['live_mode'] === $live) {
                return (string) $row['code'];
            }
        }

        return (string) $rows[0]['code'];
    }

    private function detectSameday(Order $order, Cart $cart = null)
    {
        $idOrder = (int) $order->id;
        $code = $this->getSamedayServiceCode((int) $order->id_carrier);
        $lockerCodes = array_merge(self::SAMEDAY_EASYBOX_CODES, self::SAMEDAY_PUDO_CODES);

        $data = null;
        $source = '';

        // 1) ps_sameday_order_locker — scris de modulul Sameday doar pentru servicii locker
        if ($this->tableExists('sameday_order_locker')) {
            $row = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'sameday_order_locker`
                WHERE `id_order` = ' . $idOrder . ' ORDER BY `id` DESC');
            if ($row && trim((string) $row['name_locker']) !== '') {
                $data = [
                    'id' => isset($row['id_locker']) ? (string) $row['id_locker'] : '',
                    'name' => (string) $row['name_locker'],
                    'address' => (string) $row['address_locker'],
                    'service_code' => isset($row['service_code']) ? (string) $row['service_code'] : '',
                ];
                $source = 'sameday_order_locker';
            }
        }

        // 2) ps_cart.sameday_locker (JSON) — disponibil înainte de hook-ul Sameday,
        //    dar doar dacă serviciul comenzii este unul de locker (altfel e o alegere veche din coș)
        if (!$data && $code !== null && in_array($code, $lockerCodes, true) && $this->columnExists('cart', 'sameday_locker')) {
            $json = Db::getInstance()->getValue('SELECT `sameday_locker` FROM `' . _DB_PREFIX_ . 'cart`
                WHERE `id_cart` = ' . (int) $order->id_cart);
            $obj = $json ? json_decode((string) $json, true) : null;
            if (is_array($obj) && !empty($obj['locker_name'])) {
                $data = [
                    'id' => isset($obj['locker_id']) ? (string) $obj['locker_id'] : '',
                    'name' => (string) $obj['locker_name'],
                    'address' => isset($obj['locker_address']) ? (string) $obj['locker_address'] : '',
                    'service_code' => (isset($obj['ooh_type']) && (int) $obj['ooh_type'] === 1) ? 'PP' : 'LN',
                ];
                $source = 'cart.sameday_locker';
            }
        }

        if (!$data) {
            return null;
        }

        // Tipul: după serviciul curierului (cel mai sigur), apoi după service_code salvat
        $svc = $code !== null && in_array($code, $lockerCodes, true) ? $code : $data['service_code'];
        $isPudo = in_array($svc, self::SAMEDAY_PUDO_CODES, true);

        $result = [
            'courier' => 'Sameday',
            'delivery_type' => $isPudo ? self::TYPE_PUDO : self::TYPE_EASYBOX,
            'locker_id' => $data['id'],
            'locker_name' => $data['name'],
            'locker_address' => $data['address'],
            'locker_city' => '',
            'locker_county' => '',
            'locker_postcode' => '',
            'source' => $source,
        ];

        // Îmbogățire din nomenclatorul local de lockere (dacă e sincronizat)
        if ($data['id'] !== '' && $this->tableExists('sameday_lockers')) {
            $l = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'sameday_lockers`
                WHERE `id_locker` = ' . (int) $data['id'] . '
                ORDER BY `live_mode` = ' . (int) Configuration::get('SAMEDAY_LIVE_MODE') . ' DESC');
            if ($l) {
                $result['locker_city'] = isset($l['city']) ? (string) $l['city'] : '';
                $result['locker_county'] = isset($l['county']) ? (string) $l['county'] : '';
                $result['locker_postcode'] = isset($l['postal_code']) ? (string) $l['postal_code'] : '';
                if ($result['locker_address'] === '' && !empty($l['address'])) {
                    $result['locker_address'] = (string) $l['address'];
                }
            }
        }

        $result['delivery_label'] = ($isPudo ? 'Sameday PUDO' : 'Sameday easybox') . ': ' . $result['locker_name'];

        return $result;
    }

    private function detectFan(Order $order)
    {
        $table = 'fancourier_order_info';
        if (!$this->tableExists($table)) {
            return null;
        }

        // Filtru opțional pe curieri (setare modul)
        $allowed = array_filter(array_map('intval', explode(',', (string) Configuration::get('LMF_FAN_CARRIERS'))));
        if ($allowed) {
            $ref = (int) Db::getInstance()->getValue('SELECT `id_reference` FROM `' . _DB_PREFIX_ . 'carrier`
                WHERE `id_carrier` = ' . (int) $order->id_carrier);
            if (!in_array((int) $order->id_carrier, $allowed, true) && !in_array($ref, $allowed, true)) {
                return null;
            }
        }

        $cols = $this->getColumns($table);
        $nameCol = $this->firstColumn($cols, ['fanbox_name', 'locker_name', 'pickup_point_name', 'pudo_name', 'fanbox']);
        if (!$nameCol) {
            return null;
        }

        $where = null;
        if (in_array('id_order', $cols, true)) {
            $where = '`id_order` = ' . (int) $order->id;
        } elseif (in_array('id_cart', $cols, true)) {
            $where = '`id_cart` = ' . (int) $order->id_cart;
        }
        if (!$where) {
            return null;
        }

        $orderBy = '';
        $pk = $this->firstColumn($cols, ['id', 'id_fancourier_order_info', 'id_info']);
        if ($pk) {
            $orderBy = ' ORDER BY `' . $pk . '` DESC';
        }

        $row = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . $table . '` WHERE ' . $where
            . ' AND `' . $nameCol . '` IS NOT NULL AND `' . $nameCol . '` <> \'\'' . $orderBy);

        // fallback: rând pe id_cart dacă tabela are ambele coloane și pe id_order nu e nimic
        if (!$row && in_array('id_order', $cols, true) && in_array('id_cart', $cols, true)) {
            $row = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . $table . '` WHERE `id_cart` = ' . (int) $order->id_cart
                . ' AND `' . $nameCol . '` IS NOT NULL AND `' . $nameCol . '` <> \'\'' . $orderBy);
        }
        if (!$row) {
            return null;
        }

        $pick = function (array $candidates) use ($row, $cols) {
            $c = $this->firstColumn($cols, $candidates);

            return $c && isset($row[$c]) ? trim((string) $row[$c]) : '';
        };

        $name = trim((string) $row[$nameCol]);

        return [
            'courier' => 'FAN Courier',
            'delivery_type' => self::TYPE_FANBOX,
            'delivery_label' => stripos($name, 'fanbox') === 0 ? $name : 'FANbox: ' . $name,
            'locker_id' => $pick(['fanbox_id', 'locker_id', 'pickup_point_id', 'pudo_id', 'fanbox_code']),
            'locker_name' => $name,
            'locker_address' => $pick(['fanbox_address', 'locker_address', 'pickup_point_address', 'pudo_address', 'fanbox_street']),
            'locker_city' => $pick(['fanbox_city', 'fanbox_locality', 'locker_city', 'city', 'locality']),
            'locker_county' => $pick(['fanbox_county', 'locker_county', 'county', 'judet']),
            'locker_postcode' => $pick(['fanbox_postcode', 'fanbox_zip', 'postal_code', 'postcode', 'zip']),
            'source' => $table . '.' . $nameCol,
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Adresă                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Creează o adresă NOUĂ (copie a adresei clientului, cu datele lockerului), folosită doar de comandă.
     * Adresa e marcată deleted=1 ca să nu apară în agenda clientului; comanda o poate folosi în continuare.
     *
     * @return int id_address nou sau 0
     */
    private function createLockerAddress($idOriginal, array $locker, &$error)
    {
        $original = new Address((int) $idOriginal);
        if (!Validate::isLoadedObject($original)) {
            $error = 'Adresa originală ' . (int) $idOriginal . ' nu există';

            return 0;
        }

        $typeLabel = $locker['delivery_type'] === self::TYPE_FANBOX ? 'FANbox'
            : ($locker['delivery_type'] === self::TYPE_PUDO ? 'Punct Sameday' : 'Easybox');

        $name = $this->cleanAddress($locker['locker_name']);
        if (stripos($name, $typeLabel) !== 0) {
            $name = $typeLabel . ': ' . $name;
        }
        $address2 = $this->cleanAddress($locker['locker_address']);

        $attempts = [true, false]; // 1) cu oraș/județ/cod locker  2) doar address1/address2
        foreach ($attempts as $withLocation) {
            $new = new Address();
            foreach (array_keys(Address::$definition['fields']) as $field) {
                if (property_exists($original, $field)) {
                    $new->{$field} = $original->{$field};
                }
            }
            $new->id_customer = (int) $original->id_customer;
            $new->alias = Tools::substr($typeLabel . ' comanda', 0, 32);
            $new->address1 = Tools::substr($name, 0, 128);
            $new->address2 = Tools::substr($address2, 0, 128);
            $new->other = Tools::substr(trim('Livrare ' . $typeLabel . ($locker['locker_id'] !== '' ? ' ID ' . $locker['locker_id'] : '')
                . "\n" . (string) $original->other), 0, 300);
            $new->deleted = 1;

            if ($withLocation) {
                $city = $this->cleanCity($locker['locker_city']);
                if ($city !== '') {
                    $sameCity = $this->normalize($city) === $this->normalize((string) $original->city);
                    $new->city = Tools::substr($city, 0, 64);
                    $pc = preg_replace('/[^a-zA-Z0-9 -]/', '', (string) $locker['locker_postcode']);
                    if ($pc !== '') {
                        $new->postcode = Tools::substr($pc, 0, 12);
                    } elseif (!$sameCity) {
                        $new->postcode = '';
                    }
                }
                if ($locker['locker_county'] !== '') {
                    $idState = $this->findStateId($locker['locker_county'], (int) $original->id_country);
                    if ($idState) {
                        $new->id_state = $idState;
                    }
                }
            }

            try {
                $valid = $new->validateFields(false, true);
                if ($valid !== true) {
                    $error = is_string($valid) ? $valid : 'validare eșuată';
                    continue;
                }
                if ($new->add()) {
                    return (int) $new->id;
                }
                $error = 'Address::add() a returnat false';
            } catch (\Throwable $e) {
                $error = $e->getMessage();
            }
        }

        return 0;
    }

    private function setOrderDeliveryAddress(Order $order, $idAddress)
    {
        // UPDATE direct: fără efecte secundare (Order::update declanșează alte hook-uri)
        Db::getInstance()->update('orders', ['id_address_delivery' => (int) $idAddress], 'id_order = ' . (int) $order->id);
        $order->id_address_delivery = (int) $idAddress;
    }

    private function findStateId($county, $idCountry)
    {
        $states = State::getStatesByIdCountry((int) $idCountry);
        if (!$states) {
            return 0;
        }
        $needle = $this->normalize(preg_replace('/^(judet(ul)?|jud\.?)\s+/i', '', $this->normalize($county)));
        foreach ($states as $s) {
            if ($this->normalize($s['name']) === $needle || $this->normalize($s['iso_code']) === $needle) {
                return (int) $s['id_state'];
            }
        }
        if (in_array($needle, ['bucuresti', 'municipiul bucuresti'], true)) {
            foreach ($states as $s) {
                if (strpos($this->normalize($s['name']), 'bucuresti') !== false) {
                    return (int) $s['id_state'];
                }
            }
        }

        return 0;
    }

    private function normalize($s)
    {
        $s = Tools::strtolower(trim((string) $s));
        $s = strtr($s, ['ă' => 'a', 'â' => 'a', 'î' => 'i', 'ș' => 's', 'ş' => 's', 'ț' => 't', 'ţ' => 't',
            'Ă' => 'a', 'Â' => 'a', 'Î' => 'i', 'Ș' => 's', 'Ş' => 's', 'Ț' => 't', 'Ţ' => 't', ]);

        return preg_replace('/\s+/', ' ', $s);
    }

    /** Elimină caracterele interzise de Validate::isAddress: ! < > ? = + @ { } _ $ % */
    private function cleanAddress($s)
    {
        $s = strip_tags((string) $s);
        $s = preg_replace('/[!<>?=+@{}_$%]/u', ' ', $s);

        return trim(preg_replace('/\s+/u', ' ', $s));
    }

    /** Elimină caracterele interzise de Validate::isCityName */
    private function cleanCity($s)
    {
        $s = strip_tags((string) $s);
        $s = preg_replace('/[!<>;?=+@#"°{}_$%]/u', ' ', $s);

        return trim(preg_replace('/\s+/u', ' ', $s));
    }

    /* ------------------------------------------------------------------ */
    /*  Email confirmare comandă                                           */
    /* ------------------------------------------------------------------ */

    /**
     * Pregătește variabilele {lmf_*} și subiectul pentru order_conf.
     */
    public function hookActionEmailSendBefore($params)
    {
        $this->mailPending = false;
        try {
            if (!isset($params['template']) || $params['template'] !== 'order_conf' || !Configuration::get('LMF_MAIL_ENABLED')) {
                return true;
            }
            $vars = isset($params['templateVars']) && is_array($params['templateVars']) ? $params['templateVars'] : [];
            $idOrder = isset($vars['{id_order}']) ? (int) $vars['{id_order}'] : 0;
            if (!$idOrder) {
                return true;
            }
            $order = new Order($idOrder);
            if (!Validate::isLoadedObject($order) || !$this->hasMailTemplate((int) $params['idLang'])) {
                return true;
            }

            $extra = $this->buildMailVars($order);
            foreach ($extra as $k => $v) {
                $params['templateVars'][$k] = $v;
            }
            $params['subject'] = 'Comanda ' . $order->reference . ' a fost înregistrată';
            $this->mailPending = true;
        } catch (\Throwable $e) {
            $this->mailPending = false;
            $this->log('email order_conf: ' . $e->getMessage(), 2);
        }

        return true;
    }

    /**
     * Înlocuiește conținutul șablonului order_conf cu cel din modul (doar dacă variabilele au fost pregătite).
     */
    public function hookActionEmailAddAfterContent($params)
    {
        try {
            if (!$this->mailPending || !isset($params['template']) || $params['template'] !== 'order_conf') {
                return;
            }
            $this->mailPending = false;
            $dir = $this->getMailTemplateDir((int) $params['id_lang']);
            if (!$dir) {
                return;
            }
            $params['template_html'] = Tools::file_get_contents($dir . 'order_conf.html');
            $params['template_txt'] = Tools::file_get_contents($dir . 'order_conf.txt');
        } catch (\Throwable $e) {
            $this->log('email template: ' . $e->getMessage(), 2);
        }
    }

    private function getMailTemplateDir($idLang)
    {
        $iso = Language::getIsoById((int) $idLang) ?: 'ro';
        $dir = _PS_MODULE_DIR_ . $this->name . '/mails/' . $iso . '/';
        if (is_file($dir . 'order_conf.html') && is_file($dir . 'order_conf.txt')) {
            return $dir;
        }

        return null;
    }

    private function hasMailTemplate($idLang)
    {
        return (bool) $this->getMailTemplateDir($idLang);
    }

    public function buildMailVars(Order $order)
    {
        require_once _PS_MODULE_DIR_ . $this->name . '/classes/LmfOrderMail.php';
        $builder = new LmfOrderMail($order, $this);

        return $builder->buildVars();
    }

    /**
     * Variabilele standard PrestaShop necesare șablonului (pentru previzualizare / email de test).
     */
    private function buildStandardMailVars(Order $order)
    {
        $customer = new Customer((int) $order->id_customer);
        $invoice = new Address((int) $order->id_address_invoice);

        return [
            '{firstname}' => $customer->firstname,
            '{lastname}' => $customer->lastname,
            '{email}' => $customer->email,
            '{order_name}' => $order->reference,
            '{id_order}' => (int) $order->id,
            '{date}' => Tools::displayDate($order->date_add, true),
            '{payment}' => $order->payment,
            '{invoice_block_html}' => AddressFormat::generateAddress($invoice, [], '<br />'),
            '{invoice_block_txt}' => AddressFormat::generateAddress($invoice, [], "\n"),
        ];
    }

    private function renderMailPreview(Order $order)
    {
        $dir = $this->getMailTemplateDir((int) $order->id_lang) ?: _PS_MODULE_DIR_ . $this->name . '/mails/ro/';
        $html = Tools::file_get_contents($dir . 'order_conf.html');
        $logo = Configuration::get('PS_LOGO_MAIL') ?: Configuration::get('PS_LOGO');
        $vars = array_merge($this->buildStandardMailVars($order), $this->buildMailVars($order), [
            '{shop_name}' => Configuration::get('PS_SHOP_NAME'),
            '{shop_url}' => $this->context->link->getPageLink('index', true),
            '{shop_logo}' => Tools::getShopDomainSsl(true) . __PS_BASE_URI__ . 'img/' . $logo,
        ]);

        return strtr($html, array_map('strval', $vars));
    }

    /* ------------------------------------------------------------------ */
    /*  Back office                                                        */
    /* ------------------------------------------------------------------ */

    public function hookDisplayAdminOrderTop($params)
    {
        try {
            $idOrder = isset($params['id_order']) ? (int) $params['id_order'] : 0;
            if (!$idOrder) {
                return '';
            }
            $order = new Order($idOrder);
            if (!Validate::isLoadedObject($order)) {
                return '';
            }

            $record = $this->getRecord($idOrder);
            $live = $this->detectLocker($order);

            $current = new Address((int) $order->id_address_delivery);
            $currentText = Validate::isLoadedObject($current)
                ? AddressFormat::generateAddress($current, [], '<br>')
                : '';

            $carrier = new Carrier((int) $order->id_carrier);

            $this->context->smarty->assign([
                'lmf_order_id' => $idOrder,
                'lmf_record' => $record,
                'lmf_live' => $live,
                'lmf_carrier' => Validate::isLoadedObject($carrier) ? $carrier->name : '',
                'lmf_current_address' => $currentText,
                'lmf_needs_fix' => $live && (!$record || (!(int) $record['id_address_new'] && !(int) $record['reverted'])),
                'lmf_config_url' => $this->getConfigUrl(),
            ]);

            return $this->display(__FILE__, 'views/templates/admin/order_panel.tpl');
        } catch (\Throwable $e) {
            return '<div class="alert alert-warning">LockermailFix: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }

    public function hookActionOrderGridDefinitionModifier($params)
    {
        try {
            $definition = $params['definition'];
            $column = (new \PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn('lmf_delivery'))
                ->setName('Livrare')
                ->setOptions(['field' => 'lmf_delivery', 'clickable' => true]);
            try {
                $definition->getColumns()->addBefore('payment', $column);
            } catch (\Throwable $e) {
                $definition->getColumns()->addBefore('actions', $column);
            }
        } catch (\Throwable $e) {
            $this->log('grid definition: ' . $e->getMessage(), 2);
        }
    }

    public function hookActionOrderGridQueryBuilderModifier($params)
    {
        try {
            /** @var \Doctrine\DBAL\Query\QueryBuilder $qb */
            $qb = $params['search_query_builder'];
            $qb->addSelect('IFNULL(lmf.`delivery_label`, \'\') AS `lmf_delivery`')
                ->leftJoin('o', _DB_PREFIX_ . self::TABLE, 'lmf', 'lmf.`id_order` = o.`id_order`');
        } catch (\Throwable $e) {
            $this->log('grid query: ' . $e->getMessage(), 2);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Configurare + diagnostic                                           */
    /* ------------------------------------------------------------------ */

    private function getConfigUrl()
    {
        return $this->context->link->getAdminLink('AdminModules', true, [], [
            'configure' => $this->name, 'module_name' => $this->name, 'tab_module' => $this->tab,
        ]);
    }

    public function getContent()
    {
        $messages = [];

        // asigură tabela / hook-urile și după upload peste versiunea veche fără reinstalare
        $this->installDb();
        foreach ($this->getHookList() as $hook) {
            if (!$this->isRegisteredInHook($hook)) {
                $this->registerHook($hook);
            }
        }

        if (Tools::getValue('lmf_preview_mail')) {
            $order = new Order((int) Tools::getValue('lmf_preview_mail'));
            if (Validate::isLoadedObject($order)) {
                header('Content-Type: text/html; charset=utf-8');
                echo $this->renderMailPreview($order);
                exit;
            }
            $messages[] = ['warning', 'Comanda nu există.'];
        }
        if (Tools::isSubmit('submitLmfTestMail')) {
            $order = new Order((int) Tools::getValue('lmf_test_order'));
            $to = trim((string) Tools::getValue('lmf_test_email'));
            if (!Validate::isLoadedObject($order)) {
                $messages[] = ['warning', 'Comanda #' . (int) Tools::getValue('lmf_test_order') . ' nu există.'];
            } elseif (!Validate::isEmail($to)) {
                $messages[] = ['warning', 'Adresa de email nu e validă.'];
            } else {
                $sent = Mail::Send(
                    (int) $order->id_lang,
                    'order_conf',
                    'Comanda ' . $order->reference . ' a fost înregistrată',
                    $this->buildStandardMailVars($order),
                    $to,
                    null, null, null, null, null, _PS_MAIL_DIR_, false, (int) $order->id_shop
                );
                $messages[] = $sent
                    ? ['success', 'Email de test pentru comanda #' . (int) $order->id . ' trimis la ' . $to . '.']
                    : ['warning', 'Trimiterea a eșuat — vezi Parametri avansați › Jurnale.'];
            }
        }

        if (Tools::isSubmit('submitLmfSettings')) {
            Configuration::updateValue('LMF_MAIL_ENABLED', (int) Tools::getValue('LMF_MAIL_ENABLED'));
            Configuration::updateValue('LMF_REPLACE_ADDRESS', (int) Tools::getValue('LMF_REPLACE_ADDRESS'));
            $car = Tools::getValue('LMF_FAN_CARRIERS', []);
            Configuration::updateValue('LMF_FAN_CARRIERS', implode(',', array_map('intval', is_array($car) ? $car : [])));
            $messages[] = ['success', 'Setări salvate.'];
        }
        if (Tools::isSubmit('submitLmfHookLast')) {
            $this->moveHookToLast('actionValidateOrder');
            $messages[] = ['success', 'Modulul a fost mutat ultimul pe actionValidateOrder.'];
        }
        if (Tools::getValue('lmf_fix_order')) {
            $id = (int) Tools::getValue('lmf_fix_order');
            $rec = $this->reapplyOrder($id);
            $messages[] = ($rec && (int) $rec['id_address_new'])
                ? ['success', 'Comanda #' . $id . ': adresa de livrare a fost setată pe locker.']
                : ['warning', 'Comanda #' . $id . ': nu s-a găsit locker sau adresa nu a putut fi creată' . ($rec && $rec['error'] ? ' (' . $rec['error'] . ')' : '') . '.'];
        }
        if (Tools::getValue('lmf_revert_order')) {
            $id = (int) Tools::getValue('lmf_revert_order');
            $messages[] = $this->revertOrder($id)
                ? ['success', 'Comanda #' . $id . ': readusă pe adresa inițială a clientului.']
                : ['warning', 'Comanda #' . $id . ': nu există adresă inițială salvată.'];
        }
        if (Tools::isSubmit('submitLmfBulk')) {
            $days = max(1, min(365, (int) Tools::getValue('lmf_days', 30)));
            $ids = Db::getInstance()->executeS('SELECT o.`id_order` FROM `' . _DB_PREFIX_ . 'orders` o
                LEFT JOIN `' . _DB_PREFIX_ . self::TABLE . '` l ON l.`id_order` = o.`id_order`
                WHERE o.`date_add` >= DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY)
                  AND (l.`id_order` IS NULL OR (l.`id_address_new` = 0 AND l.`reverted` = 0))
                ORDER BY o.`id_order` ASC');
            $fixed = 0;
            $total = 0;
            foreach ((array) $ids as $r) {
                ++$total;
                try {
                    $rec = $this->processOrder(new Order((int) $r['id_order']));
                    if ($rec && (int) $rec['id_address_new']) {
                        ++$fixed;
                    }
                } catch (\Throwable $e) {
                    $this->log('bulk ' . $r['id_order'] . ': ' . $e->getMessage(), 3, (int) $r['id_order']);
                }
            }
            $messages[] = ['success', 'Verificate ' . $total . ' comenzi din ultimele ' . $days . ' zile; adresă locker setată pe ' . $fixed . '.'];
        }

        $this->context->smarty->assign([
            'lmf_messages' => $messages,
            'lmf_action' => $this->getConfigUrl(),
            'lmf_replace' => (int) Configuration::get('LMF_REPLACE_ADDRESS'),
            'lmf_mail_enabled' => (int) Configuration::get('LMF_MAIL_ENABLED'),
            'lmf_employee_email' => isset($this->context->employee->email) ? $this->context->employee->email : '',
            'lmf_last_order' => (int) Db::getInstance()->getValue('SELECT MAX(`id_order`) FROM `' . _DB_PREFIX_ . 'orders`'),
            'lmf_fan_carriers' => array_filter(array_map('intval', explode(',', (string) Configuration::get('LMF_FAN_CARRIERS')))),
            'lmf_carriers' => Carrier::getCarriers((int) $this->context->language->id, false, false, false, null, Carrier::ALL_CARRIERS),
            'lmf_diag' => $this->getDiagnostics(),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    private function getDiagnostics()
    {
        $db = Db::getInstance();
        $diag = [];

        // ordinea modulelor pe actionValidateOrder
        $idHook = (int) Hook::getIdByName('actionValidateOrder');
        $diag['hook_modules'] = $idHook ? $db->executeS('SELECT m.`name`, hm.`position`, hm.`id_shop`
            FROM `' . _DB_PREFIX_ . 'hook_module` hm
            JOIN `' . _DB_PREFIX_ . 'module` m ON m.`id_module` = hm.`id_module`
            WHERE hm.`id_hook` = ' . $idHook . ' ORDER BY hm.`id_shop`, hm.`position`') : [];

        // tabele relevante + coloane
        $tables = [];
        $like = ['%sameday%', '%fan%', '%locker%', '%box%', '%pudo%'];
        $seen = [];
        foreach ($like as $pattern) {
            $rows = $db->executeS('SHOW TABLES LIKE \'' . pSQL(_DB_PREFIX_ . $pattern) . '\'');
            foreach ((array) $rows as $r) {
                $t = (string) reset($r);
                if (isset($seen[$t])) {
                    continue;
                }
                $seen[$t] = true;
                $cols = $db->executeS('SHOW COLUMNS FROM `' . bqSQL($t) . '`');
                $tables[] = [
                    'name' => $t,
                    'columns' => implode(', ', array_map(function ($c) { return $c['Field']; }, (array) $cols)),
                    'rows' => (int) $db->getValue('SELECT COUNT(*) FROM `' . bqSQL($t) . '`'),
                ];
            }
        }
        $diag['tables'] = $tables;
        $diag['cart_has_sameday_locker'] = $this->columnExists('cart', 'sameday_locker');

        // curieri Sameday și codurile lor
        $diag['sameday_services'] = $this->tableExists('sameday_services')
            ? $db->executeS('SELECT s.`id_carrier`, s.`code`, s.`name`, s.`live_mode`, c.`name` AS carrier_name, c.`deleted`
                FROM `' . _DB_PREFIX_ . 'sameday_services` s
                LEFT JOIN `' . _DB_PREFIX_ . 'carrier` c ON c.`id_carrier` = s.`id_carrier`
                WHERE s.`id_carrier` IS NOT NULL AND s.`id_carrier` > 0 ORDER BY s.`live_mode` DESC, s.`code`')
            : [];

        // ultimele comenzi
        $orders = $db->executeS('SELECT o.`id_order`, o.`reference`, o.`date_add`, o.`id_carrier`, o.`id_cart`,
                o.`id_address_delivery`, o.`id_address_invoice`, c.`name` AS carrier
            FROM `' . _DB_PREFIX_ . 'orders` o
            LEFT JOIN `' . _DB_PREFIX_ . 'carrier` c ON c.`id_carrier` = o.`id_carrier`
            ORDER BY o.`id_order` DESC LIMIT 20');
        $list = [];
        foreach ((array) $orders as $o) {
            $order = new Order((int) $o['id_order']);
            $det = null;
            try {
                $det = $this->detectLocker($order);
            } catch (\Throwable $e) {
                $det = ['delivery_label' => 'EROARE: ' . $e->getMessage(), 'source' => ''];
            }
            $addr = new Address((int) $o['id_address_delivery']);
            $o['delivery_now'] = Validate::isLoadedObject($addr) ? trim($addr->address1 . ' ' . $addr->address2 . ', ' . $addr->city) : '?';
            $o['sameday_code'] = $this->getSamedayServiceCode((int) $o['id_carrier']);
            $o['detected'] = $det;
            $o['record'] = $this->getRecord((int) $o['id_order']);
            $list[] = $o;
        }
        $diag['orders'] = $list;

        // adrese din agenda clienților modificate de versiunile vechi (1.0.x) ale modulului
        $diag['contaminated'] = $db->executeS('SELECT a.`id_address`, a.`id_customer`, a.`alias`, a.`address1`, a.`address2`, a.`city`,
                (SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders` o2 WHERE o2.`id_address_delivery` = a.`id_address`) AS orders_count
            FROM `' . _DB_PREFIX_ . 'address` a
            WHERE a.`deleted` = 0 AND (a.`alias` LIKE \'Easybox:%\' OR a.`alias` LIKE \'FANbox:%\')
            ORDER BY a.`id_address` DESC LIMIT 100');

        return $diag;
    }

    /* ------------------------------------------------------------------ */
    /*  Utilitare                                                          */
    /* ------------------------------------------------------------------ */

    public function getRecord($idOrder)
    {
        if (!$this->tableExists(self::TABLE)) {
            return null;
        }
        $row = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE `id_order` = ' . (int) $idOrder);

        return $row ?: null;
    }

    private function saveRecord(array $r)
    {
        $now = date('Y-m-d H:i:s');
        $data = [];
        foreach ($r as $k => $v) {
            $data[$k] = is_int($v) ? $v : pSQL(Tools::substr((string) $v, 0, 255));
        }
        $data['date_upd'] = $now;
        if ($this->getRecord((int) $r['id_order'])) {
            Db::getInstance()->update(self::TABLE, $data, 'id_order = ' . (int) $r['id_order']);
        } else {
            $data['date_add'] = $now;
            Db::getInstance()->insert(self::TABLE, $data);
        }
    }

    private function tableExists($table)
    {
        $key = 't:' . $table;
        if (!isset($this->schemaCache[$key])) {
            $this->schemaCache[$key] = (bool) Db::getInstance()->executeS('SHOW TABLES LIKE \'' . pSQL(_DB_PREFIX_ . $table) . '\'');
        }

        return $this->schemaCache[$key];
    }

    private function getColumns($table)
    {
        $key = 'c:' . $table;
        if (!isset($this->schemaCache[$key])) {
            $cols = [];
            if ($this->tableExists($table)) {
                foreach ((array) Db::getInstance()->executeS('SHOW COLUMNS FROM `' . bqSQL(_DB_PREFIX_ . $table) . '`') as $c) {
                    $cols[] = $c['Field'];
                }
            }
            $this->schemaCache[$key] = $cols;
        }

        return $this->schemaCache[$key];
    }

    private function columnExists($table, $column)
    {
        return in_array($column, $this->getColumns($table), true);
    }

    private function firstColumn(array $cols, array $candidates)
    {
        foreach ($candidates as $c) {
            if (in_array($c, $cols, true)) {
                return $c;
            }
        }

        return null;
    }

    private function log($msg, $severity = 1, $idOrder = 0)
    {
        try {
            PrestaShopLogger::addLog('[LockermailFix] ' . $msg, (int) $severity, null, $idOrder ? 'Order' : null, $idOrder ? (int) $idOrder : null, true);
        } catch (\Throwable $e) {
            // nimic — logarea nu trebuie să blocheze nimic
        }
    }
}
